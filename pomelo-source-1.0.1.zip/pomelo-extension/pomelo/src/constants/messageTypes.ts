
enum MessageTypes
{
    Error = "error",
    Info = "info",
    Warning = "warning"
};

export default MessageTypes;