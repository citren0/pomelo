
const config = {
    baseURL: "https://api.pomeloprod.com:443",
    login: "/api/login",
    newToken: "/api/newtoken"
};

export default config;