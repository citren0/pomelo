
enum Pages
{
    Login = "Login",
    Home = "Home",
    Welcome = "Welcome",
};

export default Pages;