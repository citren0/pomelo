
import './Login.css';
import LoginForm from './LoginForm/LoginForm';


const Login = () =>
{

    return (
        <>
            <LoginForm />
        </>
    );
};

export default Login;